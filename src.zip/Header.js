import React from "react";
import { Fragment } from "react";
import mealsImg from "../../assets/quality-meals.jpeg";
import classes from "./Header.module.css";
import HeaderCartButton from "./HeaderCartButton";
// This function includes the code to display the header
const Header = (props) => {
  return (
    <Fragment>
      <header className={classes.header}>
        <h1>Delicious Meals</h1>

        <HeaderCartButton onClick={props.onShowCart} />
      </header>
      <div className={classes["main-image"]}>
        <img src={mealsImg} />
      </div>
    </Fragment>
  );
};

export default Header;
