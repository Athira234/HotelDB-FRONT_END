export const data = [
  {
    id: 101,
    name: "Taj",
    location: "Mumbai",
    phone: "9876543210",
    email: "taj@taj.com",
    petfriendly: true,
    rating: 5,
  },
  {
    id: 102,
    name: "Hyatt",
    location: "Bangalore",
    phone: "7894561230",
    email: "hyatt@hyatt.com",
    petfriendly: false,
    rating: 4,
  },
  {
    id: 103,
    name: "Leela",
    location: "Mumbai",
    phone: "8795463210",
    email: "leela@leela.com",
    petfriendly: true,
    rating: 5,
  },
];
