import Login from "./layout/Login";
import Home from "./layout/Home";
import { ReactDOM } from "react";
import React from "react";

function App() {
  return (
    <div>
      {/* <Login /> */}
      <Home />
    </div>
  );
}

export default App;
