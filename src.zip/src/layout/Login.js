import React, { Component } from "react";
import "../assets/Styles/Login.css";
import Button from "../core/Button";
// import AppBar from "../core/ApplicationBar";
class Login extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <div>
        <div className="container">
          {/* <AppBar /> */}
          <div className="form">
            <center>
              <h3>Login</h3>
            </center>
            <br />
            <br />
            <form action="#" className="login-form">
              Username<input type="text" name="username"></input>
              <br />
              Password
              <input type="text" name="password" />
              <Button label="LOGIN" />
              <p className="message">
                Don't Have an Account?<a href="#"> Login</a>
              </p>
            </form>
          </div>
        </div>
      </div>
    );
  }
}

export default Login;
