import React from "react";
import Navbar from "../core/NavBar";
import HotelList from "./HotelList";

class Home extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <div>
        <Navbar />
        <HotelList />
      </div>
    );
  }
}
export default Home;
