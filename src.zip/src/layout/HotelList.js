import ReactDataGrid from "react-data-grid";
import { data } from "../utils/datasource";
import React, { Component, Fragment } from "react";
import Search from "../core/Search";
// import Navbar from "../core/NavBar";
import addIcon from "../assets/icons8-plus-math-48.png";
import "../assets/Styles/HotelList.css";
import { textAlign } from "@mui/system";

const columns = [
  // {
  //   key: "id",
  //   name: "",
  //   hidden: true,
  // },
  {
    key: "name",
    name: "Hotel",
    // width: 150,
    editable: true,
  },
  {
    key: "location",
    name: "Location",
    // width: 150,
    editable: true,
  },
  {
    key: "phone",
    name: "Phone",
    type: "number",
    // width: 110,
    editable: true,
  },
  {
    key: "email",
    name: "Email",
    type: "string",
    // width: 110,
    editable: true,
  },
  {
    key: "petfriendly",
    name: "Pet-Friendly",
  },
  {
    key: "rating",
    name: "Rating",
    type: "number",
    // width: 110,
    editable: true,
  },
  {
    key: "actions",
    name: "Actions",
  },
];
// const columns = [
//   { key: "id", name: "ID" },
//   { key: "title", name: "Title" },
// ];
//const rows = [{ id: 1, title: "Title 1" }];
const rowGetter = (rowNumber) => data[rowNumber];

// rowGetter = rowGetter.map((a) => `(${Object.values(a)})`).join(", ");
class HotelList extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <div>
        <br />
        <br />
        {data.length} Hotels <Search />
        <br />
        <br />
        <ReactDataGrid
          style={{
            height: "400px",
            innerWidth: "400px",
          }}
          columns={columns}
          rowGetter={rowGetter}
          rowsCount={data.length}
          // minHeight={1000}
          // minWidth={9000}
        ></ReactDataGrid>
        <button className="btn">
          <img className="img" src={addIcon} />
        </button>
      </div>
    );
  }
}
export default HotelList;
