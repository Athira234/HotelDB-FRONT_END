import React from "react";
import "../assets/Styles/Button.css";

// const buttonStyle = {
//   margin: "10px 0",

// };

const Button = ({ label, handleClick }) => (
  <button className="btn" onClick={handleClick}>
    {label}
  </button>
);

export default Button;
