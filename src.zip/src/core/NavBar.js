import React from "react";
import "../assets/Styles/NavBar.css";
import Icon from "../core/Icon";
function NavBar() {
  return (
    <div className="navbar">
      <div className="links">
        <a href="/Hotels">Hotels</a>

        <a style={{ marginLeft: "84rem" }} href="#">
          <Icon />
        </a>
      </div>
    </div>
  );
}

export default NavBar;
